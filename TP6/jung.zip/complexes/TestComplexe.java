package jung.complexes;

public class TestComplexe {
	public static void main(String[] args) {
		Complexe c1 = new ComplexeCartesien(1,3);
		Complexe c2 = new ComplexeCartesien(1,1);
		Complexe c3 = ComplexeUtil.add(c1, c2);
		Complexe c4 = ComplexeUtil.mul(c1, c2);
		Complexe c5 = new ComplexeCartesien(-3,4);
		Complexe c6 = ComplexeUtil.mul(c1, c5);
		Complexe c7 = ComplexeUtil.complexeToCartesien(c6);
		System.out.println("Complexe c1 : " + c1);
		System.out.println("Complexe c2 : " + c2);
		System.out.println("Complexe c3 : " + c3);
		System.out.println("Complexe c4 : " + c4);
		System.out.println("Complexe c6 : " + c6);
		System.out.println("Complexe c7 : " + c7);
	}

}
