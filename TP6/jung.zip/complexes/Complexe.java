package jung.complexes;

interface Complexe{
	double reelle();
	double imaginaire();
	double module();
	double argument();
}