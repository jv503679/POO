package jung.complexes;

public class ComplexeCartesien implements Complexe{
	private final double re, im;
	
	public ComplexeCartesien(double re, double im){
		this.re = re;
		this.im = im;
	}
	
	public double reelle(){
		return re;
	}
	
	public double imaginaire(){
		return im;
	}
	
	public double module(){
		return Math.sqrt(re * re + im * im);
	}
	
	public double argument(){
		return Math.atan2(im,re);
	}
	
	public String toString(){
		return String.format("z = %f + i*%f", re, im);
	}
	
}