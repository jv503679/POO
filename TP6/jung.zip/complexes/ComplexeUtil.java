package jung.complexes;

public final class ComplexeUtil{
	// création d'un nombre complexe à partir de ses coordonnées cartésiennes,
	// création d'un nombre complexe à partir de ses coordonnées polaires,
	// conversion d'un nombre complexe en un nombre complexe polaire,
	// conversion d'un nombre complexe en un nombre complexe cartésien,
	// addition de deux nombres complexes,
	// soustraction de deux nombres complexes,
	// multiplication de deux nombres complexes,
	// division de deux nombres complexes.
	
	static public Complexe cartesien(double re, double im){
		return new ComplexeCartesien(re, im);
	}
	
	static public Complexe polaire(double mod, double arg){
		return new ComplexePolaire(mod, arg);
	}
	
	static public Complexe complexeToPolaire(Complexe c){
		return new ComplexePolaire(c.module(), c.argument());
	}
	
	static public Complexe complexeToCartesien(Complexe c){
		return new ComplexeCartesien(c.reelle(), c.imaginaire());
	}
	
	static public Complexe add(Complexe c1, Complexe c2){
		return new ComplexeCartesien(c1.reelle() + c2.reelle(), c1.imaginaire() + c2.imaginaire());
	}
	
	static public Complexe sub(Complexe c1, Complexe c2){
		return new ComplexeCartesien(c1.reelle() - c2.reelle(), c1.imaginaire() - c2.imaginaire());
	}
	
	static public Complexe mul(Complexe c1, Complexe c2){
		return new ComplexePolaire(c1.module() * c2.module(), c1.argument() + c2.argument());
	}
	
	static public Complexe div(Complexe c1, Complexe c2){
		return new ComplexePolaire(c1.module() / c2.module(), c1.argument() - c2.argument());
	}
}