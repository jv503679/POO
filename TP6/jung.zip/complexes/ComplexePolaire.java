package jung.complexes;

public class ComplexePolaire implements Complexe{
	private double mod, arg;
	
	public ComplexePolaire(double mod, double arg){
		this.mod = mod;
		this.arg = arg;
	}
	
	public double reelle(){
		return Math.cos(arg) * mod;
	}
	
	public double imaginaire(){
		return Math.sin(arg) * mod;
	}
	
	public double module(){
		return mod;
	}
	
	public double argument(){
		return arg;
	}
	
	public String toString(){
		return String.format("z = %f * e^(i*%f)", mod, arg);
	}
	
}