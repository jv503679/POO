package jung.formes;
import javax.swing.JFrame;

public class PanelFrame {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(800, 400);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		frame.getContentPane().add(new TestFormeGeometrique(50));
		frame.setVisible(true);
	}
}
