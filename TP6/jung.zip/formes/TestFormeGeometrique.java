package jung.formes;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

class TestFormeGeometrique extends JPanel {
	AbstractFormeGeometrique[] formes;
	
	private int rand(int min, int max){
		return (int)(Math.random() * (max - min)) + min;
	}
	
	TestFormeGeometrique(int number){
		formes = new AbstractFormeGeometrique[number];
		//creation des formes
		for(int i = 0; i < number; i++){
			formes[i] = new Ellipse(new Point(rand(0,800), rand(0,400)), rand(10,60), rand(10,60));
			formes[i].setDessin(new Color(rand(0,255),rand(0,255),rand(0,255)));
		}
	}
	
	protected void paintComponent(Graphics g) {
		for(AbstractFormeGeometrique f : formes){
			f.draw(g);
		}
		
	}
}