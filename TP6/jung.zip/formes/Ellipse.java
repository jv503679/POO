package jung.formes;

import java.awt.Graphics;

public class Ellipse extends AbstractFormeGeometrique{
	private final int width, height;
	
	public Ellipse(Point p, int width, int height){
		super(p);
		this.width = width;
		this.height = height;
	}
	
	public double getAire(){
		return Math.PI * width * height;
	}
	
	public double getPerim(){
		return Math.PI * Math.sqrt(2 * (width*width + height*height));
	}
	
	public double getWidth(){
		return width;
	}
	
	public double getHeight(){
		return height;
	}

	public void draw(Graphics g){
		g.setColor(getDessin());
		g.fillOval(getPos().getX(), getPos().getY(), width, height);
	}

	public String toString(){
		return String.format("Ellipse - (%f, %f), demi-axes = (%f, %f)", getPos().getX(), getPos().getY(), width, height);
	}
	
}