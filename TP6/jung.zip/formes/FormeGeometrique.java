package jung.formes;

import java.awt.Graphics;

interface FormeGeometrique {
	Point getPos();
	void setPos(Point p);
	double getAire();
	double getPerim();
	void draw(Graphics g);
}