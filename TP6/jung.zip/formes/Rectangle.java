package jung.formes;

import java.awt.Graphics;

public class Rectangle extends AbstractFormeGeometrique{
	private final int width, height;
	
	public Rectangle(Point p, int width, int height){
		super(p);
		this.width = width;
		this.height = height;
	}
	
	public double getAire(){
		return width * height;
	}
	
	public double getPerim(){
		return (width + height) * 2;
	}
	
	public double getWidth(){
		return width;
	}
	
	public double getHeight(){
		return height;
	}
	
	public void draw(Graphics g){
		g.setColor(getDessin());
		g.fillRect(getPos().getX(), getPos().getY(), width, height);
	}

	public String toString(){
		return String.format("Rectangle - (%f, %f), Dim : W = %f, H = %f", getPos().getX(), getPos().getY(), width, height);
	}
	
}