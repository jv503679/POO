package jung.formes;

public class Cercle extends Ellipse{
	
	public Cercle(Point p, int rayon){
		super(p, rayon, rayon);
	}
	public String toString(){
		return String.format("Cercle - (%f, %f), rayon = %f", getPos().getX(), getPos().getY(), getWidth());
	}
}