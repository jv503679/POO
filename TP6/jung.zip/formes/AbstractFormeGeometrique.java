package jung.formes;

import java.awt.Color;

abstract class AbstractFormeGeometrique implements FormeGeometrique{
	private Point p;
	private Color fond, dessin;
	
	AbstractFormeGeometrique(Point p){
		super();
		this.p = p;
		this.fond = Color.BLACK;
		this.dessin = Color.WHITE;
	}
	
	public Point getPos(){
		return p;
	}
	public void setPos(Point p){
		this.p = p;
	}
	
	public Color getFond(){
		return fond;
	}
	public Color getDessin(){
		return dessin;
	}
	
	public void setFond(Color fond){
		this.fond = fond;
	}
	public void setDessin(Color dessin){
		this.dessin = dessin;
	}
	
}