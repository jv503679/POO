package jung.formes;

public class Carre extends Rectangle{
	public Carre(Point p, int width){
		super(p, width, width);
	}

	public String toString(){
		return String.format("Carré - (%f, %f), Length = %f", getPos().getX(), getPos().getY(), getWidth());
	}
}