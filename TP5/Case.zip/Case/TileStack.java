package Case;

public class TileStack {
	private Tile[] tiles;
	private int pointer;
	
	TileStack(Tiles[] tiles){
		this.tiles = tiles;
		pointer = tiles.length - 1;
	}
	
	public Tile pop(){
		if(pointer < 0){
			return null;
		}
		Tile tile = tiles[pointer];
		tiles[pointer] = null;
		pointer--;
		return tile;
	}

}
