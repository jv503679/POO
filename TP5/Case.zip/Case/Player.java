package Case;

public class Player {
	Tile tile;
	Meeple[] meeples;
	
	
	public Player(){
		for(int i = 0; i < 6; i++){
			meeples[i] = Meeple.NEUTRE;
		}
	}
	
	private boolean isPlayable(Case[][] cases, Case c, Tile t){
		Case[] neighbours = c.getNeighbours(cases);
		for(int i = 0; i < 4; i++){
			if(neighbours[i] != null && t.getSide(i) != neighbours[i].getTile().getOppSide(i)){
				return false;
			}
		}
		return true;
	}
	
	public void placeTile(Board board){
		Coordonnees cord = chooseCase(board);
		if(cord == null){
			System.out.println(String.format("Le joueur n'a pas pu placer sa tuile"));
			return;
		}
		Case[][] cases = board.getCases();
		int max = (int)Math.sqrt(cases.length) / 2;
		int x = cord.getX() + max;
		int y = cord.getY() + max;
		Case c = new Case(cord);
		if(isPlayable(cases, c, this.tile)){
			c.addTile(this.tile);
			board.addCase(c, x, y);
		}
		this.tile = null;
		System.out.println(String.format("Le joueur a placé sa tuile sur la case (%i, %i)", x, y));
	}
	
	public Coordonnees chooseCase(Board board){
		Coordonnees[][] coordonnees = board.getPlayableCases();
		Case[][] cases = board.getCases();
		int x, y;
		for(int orientation = 0; orientation < 4; orientation++){
			for(Coordonnees[] cords : coordonnees){
				for(Coordonnees cord : cords){
					x = cord.getX(); y = cord.getY();
					if(isPlayable(cases, cases[x][y], tile)){
						return cord;
					}
				}
			}
		}
		return null;
	}
	
	public void draw(TileStack tiles){
		this.tile = tiles.pop();
	}
	
}
