package Case;

public class Case implements CaseInterface{
	private final Coordonnees cord;
	private Meeple meeple;
	private final Tile tile;
	
	//Constructeur
	public Case(Coordonnees cord){
		this.cord = cord;
		this.meeple = null;
	}
	
	public void addTile(Tile tile){
		this.tile = tile;
	}
	
	//Est-ce qu'il y a un meeple sur la case ?
	public boolean isThereMeeple(){
		return meeple != null;
	}
	
	//Ajouter un meeple sur la case
	public void addMeeple(Meeple meeple){
		this.meeple = meeple;
	}
	
	//Supprimer le meeple de la case, renvoie le meeple supprimé
	public Meeple remMeeple(){
		Meeple meeple = this.meeple;
		this.meeple = null;
		return meeple;
	}
	
	//Renvoie voisins : haut, droite, bas, gauche
	public Case[] getNeighbours(Case[][] cases){
		Case[] neighbours = new Case[4];
		int max = (int)Math.sqrt(cases.length) / 2;
		int x = cord.getX() + max;
		int y = cord.getY() + max;
		neighbours[0] = cases[x][y-1];
		neighbours[1] = cases[x+1][y];
		neighbours[2] = cases[x][y+1];
		neighbours[3] = cases[x-1][y];
		return neighbours;
	}
	
	public Coordonnees[] getPlayableNeighbours(Case[][] cases){
		Case[] neighbours = getNeighbours(cases);
		Coordonnees[] playableNeighbours = new Coordonnees[4];
		int max = (int)Math.sqrt(cases.length) / 2;
		int x = cord.getX() + max;
		int y = cord.getY() + max;
		if(cases[x][y-1] == null){ playableNeighbours[0] = new Coordonnees(x, y-1); }
		if(cases[x+1][y] == null){ playableNeighbours[1] = new Coordonnees(x+1, y); }
		if(cases[x][y+1] == null){ playableNeighbours[2] = new Coordonnees(x, y+1); }
		if(cases[x-1][y] == null){ playableNeighbours[3] = new Coordonnees(x-1, y); }
		return playableNeighbours;
	}
	
	public Coordonnees getCords(){
		return cord;
	}
	
	public Tile getTile(){
		return tile;
	}
}
