package Case;

interface CaseInterface {
	//Ajouter une tuile
	void addTile(Tile t);
	
	//Est-ce qu'il y a un Meeple?
	boolean isThereMeeple();
	
	//Ajouter un Meeple sur une case
	void addMeeple(Meeple m);
	
	//Retirer le Meeple de la case
	Meeple remMeeple();
	
	//Recuperer les voisins
	Case[] getNeighbours(Case[][] cases);
	
	//Recuperer les coordonnees de la case
	Coordonnees getCords();
	
	//Recuperer la tuile de la case
	Tile getTile();
}