package Case;

public class Board {
	private Case[][] cases;
	private Case[] fullcases;
	private int numberOfFullCases;
	
	public Board(int i){
		cases = new Case[i+2][i+2];
		fullcases = new Case[i*i+4];
		cases[i/2][i/2] = new Case(new Coordonnees(i/2, i/2));
		cases[i/2][i/2].addTile("TILE DE DEPART");
		fullcases[0] = cases[i/2][i/2];
	}
	
	public Coordonnees[][] getPlayableCases(){
		Coordonnees[][] playableCases = new Coordonnees[numberOfFullCases][4];
		for(int i = 0; i < numberOfFullCases; i++){
			playableCases[i] = fullcases[i].getPlayableNeighbours(cases);
		}
		return playableCases;
	}
	
	public Case[][] getCases(){
		return cases;
	}
	
	public void addCase(Case c, int x, int y){
		cases[x][y] = c;
		fullcases[numberOfFullCases] = c;
		numberOfFullCases++;
	}
	
}
