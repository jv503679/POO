package Case;

public class Coordonnees{
	//Coordonnes attachees a une case, non modifiable
	private final int x,y;
	public Coordonnees(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	//Recuperer X
	public int getX(){
		return x;
	}
	//Recuperer Y
	public int getY(){
		return y;
	}
}