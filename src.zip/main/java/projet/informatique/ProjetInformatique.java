package projet.informatique;

import Board.*;

public class ProjetInformatique {

    //Phase durant laquelle le joueur courant pioche
    static void drawPhase(Player player, TileStack tiles) {
        player.draw(tiles);
    }

    //Phase durant laquelle le joueur courant joue (pose une tuile)
    static void playPhase(Player player, Board board) {
        player.placeTile(board);
    }

    public static void main(String[] args) {
        //On créer la pile de tuiles
        TileStack tiles = new TileStack();
        //On créer le plateau de jeu (72 tuiles jouables)
        Board board = new Board(72);
        //On créer un nouveau joueur (IA)
        Player player = new Player();
        

        //Déroulement de 30 tours
        for (int i = 0; i < 71; i++) {
            drawPhase(player, tiles);
            playPhase(player, board);
        }
    }

}
