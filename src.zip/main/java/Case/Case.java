package Case;

import Board.*;
import Tile.Tile;

public class Case implements CaseInterface {

    private final Coordonnees cord;
    private Meeple meeple;
    private Tile tile; // mettre dans le constructeur ?

    //Constructeur
    public Case(Coordonnees cord) {
        this.cord = cord;
        this.meeple = null;
        this.tile = null;
    }

    public void addTile(Tile tile) {
        this.tile = tile;
    }

    //Est-ce qu'il y a un meeple sur la case ?
    public boolean isThereMeeple() {
        return meeple != null;
    }

    //Ajouter un meeple sur la case
    public void addMeeple(Meeple meeple) {
        this.meeple = meeple;
    }

    //Supprimer le meeple de la case, renvoie le meeple supprimé
    public Meeple remMeeple() {
        Meeple meeple = this.meeple;
        this.meeple = null;
        return meeple;
    }

    //Renvoie voisins : haut, droite, bas, gauche
    public Coordonnees[] getNeighbours() {
        Coordonnees[] neighbours = new Coordonnees[4];
        int x = cord.getX();
        int y = cord.getY();
        neighbours[0] = new Coordonnees(x-1, y);
        neighbours[1] = new Coordonnees(x, y-1);
        neighbours[2] = new Coordonnees(x+1, y);
        neighbours[3] = new Coordonnees(x, y+1);
        return neighbours;
    }

    //Retourne la liste des coordonnées des voisins vide (sur lesquels on peut jouer)
    public Coordonnees[] getPlayableNeighbours(Case[][] cases) {
        Coordonnees[] playableNeighbours = new Coordonnees[4];
        int max = cases.length / 2 + 1;
        int cordx = cord.getX();
        int cordy = cord.getY();
        int x = cordx + max;
        int y = cordy + max;
        
        //Si la case est vide, ou qu'elle ne contient pas de tuile, alors elle est jouable.
        if (cases[x - 1][y] == null || cases[x-1][y].getTile() == null) {
            playableNeighbours[0] = new Coordonnees(cordx - 1, cordy);
        }
        if (cases[x][y - 1] == null || cases[x][y-1].getTile() == null) {
            playableNeighbours[1] = new Coordonnees(cordx, cordy - 1);
        }
        if (cases[x + 1][y] == null || cases[x+1][y].getTile() == null) {
            playableNeighbours[2] = new Coordonnees(cordx + 1, cordy);
        }
        if (cases[x][y + 1] == null || cases[x][y+1].getTile() == null) {
            playableNeighbours[3] = new Coordonnees(cordx, cordy + 1);
        }
        return playableNeighbours;
    }

    //Retourne les coordonnées de la case
    public Coordonnees getCords() {
        return cord;
    }

    //Retourne la tuile de la case
    public Tile getTile() {
        return tile;
    }

    //Affiche la case (les coordonnees)
    public String toString() {
        return "Case " + cord;
    }
}
