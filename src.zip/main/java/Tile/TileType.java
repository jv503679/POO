package Tile;

public enum TileType {
    FIELD(0), ROAD(1), CITY(2), ABBEY(3), CROSSROAD(4);

    private final int type;

    TileType(int type) {
        this.type = type;
    }
}
