package Tile;

public class Tile {

    private TileType[] sides;
    private TileType center;
    private boolean shield;
    public static final Tile starterTile = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.FIELD, TileType.ROAD}, TileType.ROAD, false);

    //Une tuile poss�de un tableau symbolisant les dessins, et un boolean symbolisant le fait qu'il poss�de un Ecu.
    public Tile(TileType[] sides, TileType center, boolean shield) {
        this.sides = sides;
        this.center = center;
        this.shield = shield;
    }



	//On effectue une rotation de 90� vers la gauche
    public void rotate() {
        TileType tmp;
        tmp = sides[0];
        for (int i = 0; i < 3; i++) {    //On stock successivement les valeurs suivantes dans les valeurs courantes
            sides[i] = sides[i+1];
        }
        sides[3] = tmp;
    }
    
    //Fonction pour afficher la tuile. Elle affiche le tableau type[].
    public String toString(){
        StringBuilder builder = new StringBuilder();
        builder.append("[");
        for(int i = 0; i < 4; i++){
            builder.append(sides[i]);
            builder.append(", ");
        }
        builder.append(center);
        builder.append("]");
        return builder.toString();
    }

    //Fonction pour r�cup�rer la nature d'un c�t�. 0 = Haut, 1 = Droite... (sens montre)
    public TileType getSide(int side) {
        return this.sides[(side + 1) % 4];
    }

    //Fonction compl�mentaire de getSide(). 0 = Bas, 1 = Gauche... (sens contraire montre)
    public TileType getOppSide(int side) {
        return this.sides[(side + 3) % 4];
    }
    //Fonction pour r�cup�rer la nature d'un centre.
    public TileType getCenter() {
        return this.center;
    }
    // retourne true si on a un shield 
    public boolean getShield() {
        return this.shield;
    }
    //on cr�e le paquet contenant toutes les tuile 
    public static Tile[] InitTilesDeck() {
        Tile[] deck = new Tile[72];
        for (int i = 0; i < 72; i++) {
            if (i < 9) {
                  deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.FIELD, TileType.ROAD, TileType.ROAD}, TileType.ROAD, false);
            }
            if ((9 <= i) && (i < 12)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.ROAD, TileType.FIELD}, TileType.ROAD, false);
            }
            if ((12 <= i) && (i < 14)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.ROAD, TileType.CITY}, TileType.ROAD, true);
            }
            if ((14 <= i) && (i < 15)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.ROAD, TileType.CITY}, TileType.CITY, false);
            }
            if ((15 <= i) && (i < 16)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.FIELD, TileType.CITY}, TileType.CITY, true);
            }
            if ((16 <= i) && (i < 19)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.ROAD, TileType.CITY}, TileType.ROAD, false);
            }
            if ((19 <= i) && (i < 22)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.ROAD, TileType.ROAD}, TileType.CROSSROAD, false);
            }
            if ((22 <= i) && (i < 30)) {
                deck[i] = new Tile(new TileType[]{TileType.ROAD, TileType.FIELD, TileType.ROAD, TileType.FIELD}, TileType.ROAD, false);
            }
            if ((30 <= i) && (i < 34)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.ROAD, TileType.ROAD, TileType.ROAD}, TileType.CROSSROAD, false);
            }
            if ((34 <= i) && (i < 39)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.FIELD, TileType.FIELD, TileType.FIELD}, TileType.FIELD, false);
            }
            if ((39 <= i) && (i < 41)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.FIELD, TileType.FIELD}, TileType.FIELD, false);
            }
            if ((41 <= i) && (i < 44)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.FIELD, TileType.CITY}, TileType.CITY, false);
            }
            if ((44 <= i) && (i < 48)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.FIELD, TileType.FIELD, TileType.FIELD}, TileType.ABBEY, false);
            }
            if ((48 <= i) && (i < 50)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.FIELD, TileType.ROAD, TileType.FIELD}, TileType.ABBEY, false);
            }
            if ((50 <= i) && (i < 53)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.FIELD, TileType.FIELD, TileType.CITY}, TileType.CITY, false);
            }
            if ((53 <= i) && (i < 55)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.CITY, TileType.FIELD, TileType.CITY}, TileType.CITY, true);
            }
            if ((55 <= i) && (i < 59)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.FIELD, TileType.ROAD}, TileType.ROAD, false);
            }
            if ((59 <= i) && (i < 62)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.FIELD, TileType.ROAD, TileType.ROAD}, TileType.ROAD, false);
            }
            if ((62 <= i) && (i < 63)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.CITY, TileType.FIELD, TileType.CITY}, TileType.CITY, false);
            }
            if ((63 <= i) && (i < 65)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.ROAD, TileType.CITY}, TileType.CITY, true);
            }
            if ((65 <= i) && (i < 66)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.CITY, TileType.CITY}, TileType.CITY, true);
            }
            if ((66 <= i) && (i < 67)) {
                deck[i] = new Tile(new TileType[]{TileType.ROAD, TileType.ROAD, TileType.ROAD, TileType.ROAD}, TileType.CROSSROAD, false);
            }
            if ((67 <= i) && (i < 69)) {
                deck[i] = new Tile(new TileType[]{TileType.CITY, TileType.FIELD, TileType.FIELD, TileType.CITY}, TileType.CITY, true);
            }
            if ((69 <= i) && (i < 72)) {
                deck[i] = new Tile(new TileType[]{TileType.FIELD, TileType.CITY, TileType.FIELD, TileType.CITY}, TileType.FIELD, false);
            }

        }
        return deck;
    }
}
