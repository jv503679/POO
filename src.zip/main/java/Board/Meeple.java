package Board;

public enum Meeple {
    NEUTRE(0), PAYSAN(1), CHEVALIER(2), VOLEUR(3), MOINE(4);
    int type;

    Meeple(int type) {
        this.type = type;
    }
}
