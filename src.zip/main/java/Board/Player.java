package Board;

import Case.*;
import Tile.*;

public class Player {

    Tile tile;
    Meeple[] meeples;

    //Constructeur du Joueur. Un joueur dispose d'une tuile et de plusieurs Meeples (meeple non encore géré)
    public Player() {
        meeples = new Meeple[6];
        for (int i = 0; i < 6; i++) {
            meeples[i] = Meeple.NEUTRE;
        }
    }

    public Tile getTile() {
        return tile;
    }

    //Retourne TRUE si la tuile t peut être posée sur la case c (voisins compatibles). FALSE sinon.
    private boolean isPlayable(Case[][] cases, Case c, Tile t) {
        Coordonnees[] neighbours = c.getNeighbours();   //On récupère le tableau des voisins.
        Case neighbour;
        int max = cases.length / 2 + 1;
        for (int rotate = 0; rotate < 4; rotate++) {
            for (int i = 0; i < 4; i++) {                                                //Pour chaque voisin
                neighbour = cases[neighbours[i].getX() + max][neighbours[i].getY() + max];
                //Si le voisin existe, s'il dispose d'une tuile et que les bords sont différents (non compatible)
                if (neighbour != null && neighbour.getTile() != null && t.getSide(i) != neighbour.getTile().getOppSide(i)) {
                    if (rotate == 3) {
                        return false;
                    }
                }
            }
            tile.rotate();
        }
        return true;
    }

    //La fonction qui permet au joueur de jouer sa tuile sur le plateau.
    public void placeTile(Board board) {
        Coordonnees cord = chooseCase(board);  //Le joueur commence par choisir une case sur laquelle jouer sa tuile.
        if (cord == null) {     //La case n'a pas pu être trouvée...
            //message d'erreur?
            System.out.println("Le joueur n'a pas réussi à placer sa tuile");
            return;
        }

        //On calcule la position de la case sur laquelle poser la tuile
        Case[][] cases = board.getCases();
        int max = cases.length / 2 + 1;
        int x = cord.getX() + max;
        int y = cord.getY() + max;

        //On a trouvé son emplacement x,y
        Case c = cases[x][y];
        c.addTile(this.tile);                    //On ajoute la tuile
        board.addFullCase(c, x, y);      //On ajoute la case aux cases remplies
        System.out.println("Le joueur a placé sa tuile sur la " + c);
        this.tile = null;                           //On supprime la tuile du joueur
    }

    //La fonction qui permet de décider ou jouer la case {IA SIMPLE}
    public Coordonnees chooseCase(Board board) {
        //On prend les coordonnees de toutes les cases sur lesquelles on peut jouer
        Coordonnees[][] coordonnees = board.getPlayableCases();
        Case[][] cases = board.getCases();
        int x, y;

        //Pour toutes les coordonnées disponibles dans le tableau des cases jouables...
        for (Coordonnees[] cords : coordonnees) {
            for (Coordonnees cord : cords) {
                //Si la coordonnees n'est pas nulle
                if (cord != null) {
                    int max = cases.length / 2 + 1;
                    x = cord.getX() + max;
                    y = cord.getY() + max;
                    //Si la case n'existe pas encore
                    if (cases[x][y] == null) {
                        board.addCase(new Case(cord), x, y);    //On créer la case sans rien mettre dedans.
                    }
                    if (isPlayable(cases, cases[x][y], tile)) {       //Si on peut jouer sur la case, alors on la sélectionne.
                        return cord;
                    }
                }
            }
        }
        System.out.println("Non trouvé");
        //Aucune case jouable trouvée...
        return null;
    }

    //Fonction qui permet de piocher une tuile de la pile de tuile.
    public void draw(TileStack tiles) {
        this.tile = tiles.pop();
    }

}
