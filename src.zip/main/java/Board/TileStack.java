package Board;

import Tile.Tile;
import java.util.Random;

public class TileStack {

    private Tile[] tiles;
    private int pointer;

    //On créer une pile de tuile selon les règles du jeu.
    public TileStack() {
        this.tiles = Tile.InitTilesDeck();
        pointer = tiles.length - 1;           //On initialise le pointeur au sommet de la pile
        shuffle(1000);                         //On mélange les tuiles (1000 permutations)
    }
    
    //Fonction pour échanger la place de deux tuiles aléatoires dans la pile
    private void shuffleOnce(){
        Random rand = new Random(); 
        int tile1 = rand.nextInt(pointer + 1) + 0;
        int tile2 = rand.nextInt(pointer + 1) + 0;
        Tile tmpTile = tiles[tile1];
        tiles[tile1] = tiles[tile2];
        tiles[tile2] = tmpTile;
    }
    
    //Fonction pour mélanger la pile
    private void shuffle(int number){
        for(int i = 0; i < number; i++){
            shuffleOnce();
        }
    }
    
    public void setTiles(Tile[] tiles){
        this.tiles = tiles;
        pointer = tiles.length - 1;
    }

    //Fonction qui permet de retirer un élément de la pile (celui du dessus)
    public Tile pop() {
        if (pointer < 0) {
            return null;
        }
        Tile tile = tiles[pointer];
        tiles[pointer] = null;
        pointer--;
        return tile;
    }

}
