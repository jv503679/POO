package Board;

import Case.Case;
import Tile.Tile;

public class Board {

    //Ensemble des cases
    private Case[][] cases;

    //Ensemble des cases remplies
    private Case[] fullcases;

    //Nombre de cases remplies
    private int numberOfFullCases;

    //Création d'un plateau.
    public Board(int i) {
        //On initialise la taille du plateau en fonction de nombre de tuiles en jeu.
        cases = new Case[i * 2 + 1][i * 2 + 1];
        fullcases = new Case[i];

        //On initialise la case du milieu de plateau avec la tuile de départ.
        cases[i + 1][i + 1] = new Case(new Coordonnees(0, 0));
        cases[i + 1][i + 1].addTile(Tile.starterTile);

        //On ajoute la case du milieu comme case remplie.
        fullcases[0] = cases[i + 1][i + 1];
        numberOfFullCases++;
    }

    //Retourne un tableau de tableau de coordonnées des cases adjacentes à celles remplies, aka les cases sur lesquelles on peut jouer.
    public Coordonnees[][] getPlayableCases() {
        Coordonnees[][] playableCases = new Coordonnees[numberOfFullCases][4];
        for (int i = 0; i < numberOfFullCases; i++) {
            playableCases[i] = fullcases[i].getPlayableNeighbours(cases);
        }
        return playableCases;
    }

    //Retourne l'ensemble de toutes les cases
    public Case[][] getCases() {
        return cases;
    }

    //Ajoute une case vide !
    public void addCase(Case c, int x, int y) {
        cases[x][y] = c;
    }

    //Ajoute une case remplie (avec une tuile)
    public void addFullCase(Case c, int x, int y) {
        cases[x][y] = c;
        fullcases[numberOfFullCases] = c;
        numberOfFullCases++;
    }

    //DEBUG
    //Affiche la liste de toutes les cases occupées par des tuiles
    public void ShowFullCases() {
        for (int i = 0; i < numberOfFullCases; i++) {
            System.out.println(fullcases[i]);
        }
    }

}
