import Case.*;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Board.Coordonnees;
import Board.Meeple;
import Tile.Tile;
import Tile.TileType;

public class CaseTest {
	private Case[][] caseTab = new Case[5][5];
	private int max = caseTab.length / 2;
	private Coordonnees cord1;
	private Coordonnees cord2;
	private Coordonnees cord3;
	private Coordonnees cord4;
	private Coordonnees cord5;
	private Coordonnees cord6;
	private Case case1;
	private Case voisin1;
	private Case voisin2;
	private Case voisin3;
	private Case voisin4;
	private Case nonVoisin;
	private Coordonnees[] voisins;
	private Coordonnees[] voisinsJouable;
	private Tile tile1;
	
	@Before public void setUp() {
		 cord1 = new Coordonnees(0,0);
		 cord2 = new Coordonnees(0,-1);
		 cord3 = new Coordonnees(1,0);
		 cord4 = new Coordonnees(0,1);
		 cord5 = new Coordonnees(-1,0);
		 cord6 = new Coordonnees(2,0);
		 case1 = new Case(cord1);
		 voisin1 = new Case(cord2);
		 voisin2 = new Case(cord3);
		 voisin3 = new Case(cord4);
		 voisin4 = new Case(cord5);
		 nonVoisin = new Case(cord6);
		 tile1 = new Tile(new TileType[] {TileType.FIELD ,TileType.FIELD,TileType.FIELD,TileType.FIELD},TileType.FIELD , false);
		 caseTab[cord1.getX() + max][cord1.getY() + max] = case1;
		 caseTab[cord2.getX() + max][cord2.getY() + max] = voisin1;
		 caseTab[cord3.getX() + max][cord3.getY() + max] = voisin2;
		 caseTab[cord4.getX() + max][cord4.getY() + max] = voisin3;
		 caseTab[cord5.getX() + max][cord5.getY() + max] = voisin4;
		 voisinsJouable = case1.getPlayableNeighbours(caseTab);
	 }
	

	@Test
	public void testIsThereMeeple() {
		case1.addMeeple(Meeple.PAYSAN);
		assertTrue("Test de isThereMeeple() et addMeeple(Meeple meeple) : fail" , case1.isThereMeeple());
		assertFalse("Test de isThereMeeple() et addMeeple(Meeple meeple) : fail" , voisin1.isThereMeeple());
		System.out.println("Test de isThereMeeple() et addMeeple(Meeple meeple) : ok");
	}

	@Test
	public void testRemMeeple() {
		voisin1.addMeeple(Meeple.PAYSAN);
		assertTrue("Test de remMeeple : fail" , voisin1.isThereMeeple());
		voisin1.remMeeple();
		assertFalse("Test de remMeeple : fail" , voisin1.isThereMeeple());
		System.out.println("Test de remMeeple : ok");
	}

	@Test
	public void testGetNeighbours() {
		assertTrue("Test de getNeighbours : fail", (case1.getNeighbours()[0].equals(voisin1.getCords()) && case1.getNeighbours()[1].equals(voisin2.getCords()) && case1.getNeighbours()[2].equals(voisin3.getCords()) && case1.getNeighbours()[3].equals(voisin4.getCords())));
		System.out.println("Test de getNeighbours : ok");
	}

	@Test
	public void testGetPlayableNeighbours() {
		assertTrue("Test de getPlayableNeighbours() : fail", (voisinsJouable[0].equals(voisin1.getCords()) && voisinsJouable[1].equals(voisin2.getCords()) && voisinsJouable[2].equals(voisin3.getCords()) && voisinsJouable[3].equals(voisin4.getCords())));
		System.out.println("Test de getPlayableNeighbours() : ok");
	}

	@Test
	public void testGetCords() {
		assertTrue("Test de getCords() : fail" , case1.getCords().equals(cord1));
		System.out.println("Test de getCords() : ok");
	}

	@Test
	public void testGetTile() {
		case1.addTile(tile1);
		assertEquals(case1.getTile() , tile1);
		assertNull(voisin1.getTile());
		System.out.println("Test de addTile(Tle tile) et getTile() : ok");
		
	}

}
