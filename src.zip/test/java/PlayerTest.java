/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import Board.*;
import Case.*;
import Tile.*;

/**
 *
 * @author jv503679
 */
public class PlayerTest {
    private Player playerTest;
    private Board boardTest;
    private TileStack tileStackTest;
    private Tile[] setOfTestingTiles;
    
    
    @Before
    public void setUp() {
        playerTest = new Player();
        boardTest = new Board(6);
        tileStackTest = new TileStack();
        setOfTestingTiles = new Tile[]{
            new Tile(new TileType[]{TileType.FIELD, TileType.FIELD, TileType.ROAD, TileType.ROAD}, TileType.ROAD, false),
            new Tile(new TileType[]{TileType.CITY, TileType.ROAD, TileType.ROAD, TileType.FIELD}, TileType.ROAD, false)
        };
        
        tileStackTest.setTiles(setOfTestingTiles);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of draw method, of class Player.
     */
    @Test
    public void testDraw() {
        System.out.println("draw");
        Tile exp = setOfTestingTiles[1];
        playerTest.draw(tileStackTest);
        assertEquals(exp, playerTest.getTile());
        Tile exp2 = setOfTestingTiles[0];
        playerTest.draw(tileStackTest);
        assertEquals(exp2, playerTest.getTile());
        playerTest.draw(tileStackTest);
        assertEquals(null, playerTest.getTile());
    }

    /**
     * Test of chooseCase method, of class Player.
     */
    @Test
    public void testChooseCase() {
        System.out.println("chooseCase");
        playerTest.draw(tileStackTest);
        
        Coordonnees res = playerTest.chooseCase(boardTest);
        assertEquals(boardTest.getCases()[6][7].getCords(), res);
        Tile all_city = new Tile(new TileType[]{TileType.CITY, TileType.CITY, TileType.CITY, TileType.CITY}, TileType.CITY, false);
        Tile all_road = new Tile(new TileType[]{TileType.ROAD, TileType.ROAD, TileType.ROAD, TileType.ROAD}, TileType.ROAD, false);
        Tile all_field = new Tile(new TileType[]{TileType.FIELD, TileType.FIELD, TileType.FIELD, TileType.FIELD}, TileType.FIELD, false);
        boardTest.addFullCase(new Case(new Coordonnees(-1,-1)), 6, 6);
        boardTest.getCases()[6][6].addTile(all_city);
        boardTest.addFullCase(new Case(new Coordonnees(0,-2)), 7, 4);
        boardTest.getCases()[7][4].addTile(all_field);
        boardTest.addFullCase(new Case(new Coordonnees(-1,1)), 6, 8);
        boardTest.getCases()[6][8].addTile(all_road);
        boardTest.addFullCase(new Case(new Coordonnees(2,0)), 9, 7);
        boardTest.getCases()[9][7].addTile(all_road);
        res = playerTest.chooseCase(boardTest);
        assertEquals(boardTest.getCases()[6][7].getCords(), res);
        playerTest.draw(tileStackTest);
        res = playerTest.chooseCase(boardTest);
        assertEquals(boardTest.getCases()[7][8].getCords(), res);
    }

    /**
     * Test of placeTile method, of class Player.
     */
    @Test
    public void testPlaceTile() {
        System.out.println("placeTile");
        playerTest.draw(tileStackTest);
        playerTest.placeTile(boardTest);
        
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
