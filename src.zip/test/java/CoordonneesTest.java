import Board.*;

import static org.junit.Assert.*;

import org.junit.Test;

public class CoordonneesTest {
	
	Coordonnees coord1 = new Coordonnees(2,0);
	Coordonnees coord2 = new Coordonnees(2,0);
	@Test
	public void testGetX() {
		assertEquals(coord1.getX(),2);
		System.out.println("Test getX() : ok");
	}

	@Test
	public void testGetY() {
		assertEquals(coord1.getY(),0);
		System.out.println("Test getY() : ok");	
	}

	@Test
	public void testEqualsCoordonnees() {
		assertTrue("Test EqualsCoordonnees : fail", coord1.equals(coord2));
	}

}
