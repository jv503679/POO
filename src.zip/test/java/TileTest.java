import Tile.*;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TileTest {
	
	private Tile tile1;
	private Tile tile2;
	private Tile expected;
	private Tile rotatedTile1;
	
	
	
	@Before public void setUp() {
		tile1 = new Tile(new TileType[]{TileType.FIELD,TileType.FIELD,TileType.ROAD,TileType.ROAD},TileType.ROAD, false);
		rotatedTile1 = new Tile(new TileType[]{TileType.FIELD,TileType.ROAD,TileType.ROAD,TileType.FIELD},TileType.ROAD, false);
		tile2 = new Tile(new TileType[]{TileType.CITY,TileType.ROAD,TileType.ABBEY,TileType.CITY},TileType.ROAD, true);
	
	}
	
	@Test
	public void testRotate() {
		tile1.rotate();
		assertEquals(tile1.getSide(0),rotatedTile1.getSide(0));
		assertEquals(tile1.getSide(1),rotatedTile1.getSide(1));
		assertEquals(tile1.getSide(2),rotatedTile1.getSide(2));
		assertEquals(tile1.getSide(3),rotatedTile1.getSide(3));
		System.out.println("Test rotate : ok");
	}

	@Test
	public void testGetShield() {
		assertEquals(tile1.getShield(), false);
		assertEquals(tile2.getShield(), true);
		System.out.println("Test getGetShield() : ok");
	}


	@Test
	public void testGetSide() {
		assertEquals(tile2.getSide(0),TileType.CITY);
		System.out.println("Test getGetSide() : ok");
	}

	@Test
	public void testGetOppSide() {
		assertEquals(tile2.getOppSide(0),TileType.ABBEY);
		System.out.println("Test getGetOppSide() : ok");

	}

	@Test
	public void testInitTilesDeck() {
		
	}

}
